const canvas = document.getElementById("jogoCanvas");
const ctx = canvas.getContext("2d");
const scoreElement = document.getElementById("score");
const livesElement = document.getElementById("lives");
const ammoElement = document.getElementById("ammo");
const winMsg = document.getElementById("winMsg");
const gameOverMsg = document.getElementById("gameOverMsg");

ctx.imageSmoothingEnabled = false;

const totalFaixas = 10;
let alturaFaixa;
let score = 0;
let vidas = 3;
let projeteis = [];
let carros = [];
let jogoAtivo = true;
let invencivel = false; // Evita perder várias vidas de uma vez só

const spriteKuromi = new Image();
spriteKuromi.src = 'personagem.png';
let imagemCarregada = false;
spriteKuromi.onload = () => { imagemCarregada = true; };

const player = {
    faixa: 9, x: 0, y: 0, w: 0, h: 0, ammo: 3,
    clipX: 80, clipY: 80, clipW: 860, clipH: 800 
};

function inicializar() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight - 52;
    alturaFaixa = canvas.height / totalFaixas;

    player.h = alturaFaixa * 1.5; 
    player.w = player.h * 1.1; 
    player.faixa = totalFaixas - 1; 
    
    resetPos();
    gerarCarros();
    atualizarUI();
}

function resetPos() {
    player.faixa = totalFaixas - 1; // Força ir para a última faixa
    player.x = canvas.width / 2 - player.w / 2;
    player.y = (player.faixa * alturaFaixa) + (alturaFaixa - player.h);
}

function gerarCarros() {
    carros = [];
    // CORREÇÃO CRUCIAL: 'i' começa em 1 e vai até menos de (totalFaixas - 1).
    // Isso significa que as faixas 0 (topo) e 9 (chão onde a Kuromi nasce) NUNCA terão fantasmas.
    for (let i = 1; i < totalFaixas - 1; i++) {
        let v = (Math.random() * 2 + 3) * (i % 2 === 0 ? 1 : -1);
        carros.push({
            x: Math.random() * canvas.width,
            y: i * alturaFaixa + (alturaFaixa * 0.1),
            w: alturaFaixa * 1.4,
            h: alturaFaixa * 0.8,
            vel: v,
            cor: i % 2 === 0 ? "#FF69B4" : "#FFC0CB",
            ativo: true
        });
    }
}

function desenharFantasma(c) {
    if (!c.ativo) return;
    ctx.fillStyle = c.cor;
    ctx.fillRect(c.x + c.w * 0.1, c.y, c.w * 0.8, c.h * 0.9); 
    ctx.fillRect(c.x, c.y + c.h * 0.3, c.w, c.h * 0.5); 
    ctx.fillRect(c.x, c.y + c.h * 0.8, c.w * 0.2, c.h * 0.2);
    ctx.fillRect(c.x + c.w * 0.4, c.y + c.h * 0.8, c.w * 0.2, c.h * 0.2);
    ctx.fillRect(c.x + c.w * 0.8, c.y + c.h * 0.8, c.w * 0.2, c.h * 0.2);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(c.x + c.w * 0.2, c.y + c.h * 0.2, c.w * 0.2, c.w * 0.2);
    ctx.fillRect(c.x + c.w * 0.6, c.y + c.h * 0.2, c.w * 0.2, c.w * 0.2);
    ctx.fillStyle = "#000000";
    ctx.fillRect(c.x + c.w * 0.25, c.y + c.h * 0.25, c.w * 0.1, c.w * 0.1);
    ctx.fillRect(c.x + c.w * 0.65, c.y + c.h * 0.25, c.w * 0.1, c.w * 0.1);
}

function loop() {
    if (!jogoAtivo) return;

    // Desenhar cenário de fundo
    ctx.fillStyle = "#FFC0CB";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < totalFaixas; i++) {
        let posY = i * alturaFaixa;
        ctx.fillStyle = (i === 0 || i === totalFaixas - 1) ? "#483D8B" : "#000000";
        ctx.fillRect(0, posY, canvas.width, alturaFaixa);
    }

    // Atualizar e desenhar tiros do jogador
    projeteis.forEach((p, pIdx) => {
        p.y -= 8; 
        ctx.fillStyle = "#00FFFF";
        ctx.fillRect(p.x, p.y, p.w, p.h);

        if (p.y < 0) projeteis.splice(pIdx, 1);
    });

    // Atualizar fantasmas
    carros.forEach(c => {
        if (!c.ativo) return;
        c.x += c.vel;
        if (c.x > canvas.width) c.x = -c.w;
        if (c.x < -c.w) c.x = canvas.width;

        desenharFantasma(c);

        // Colisão: Projétil atinge Fantasma
        projeteis.forEach((p, pIdx) => {
            if (p.x < c.x + c.w && p.x + p.w > c.x && p.y < c.y + c.h && p.y + p.h > c.y) {
                c.ativo = false; 
                projeteis.splice(pIdx, 1);
                setTimeout(() => { c.ativo = true; }, 4000); // Revive em 4s
            }
        });

        // Colisão: Fantasma atinge Player (SÓ SE NÃO ESTIVER INVENCÍVEL)
        if (!invencivel && player.x + 25 < c.x + c.w && player.x + player.w - 25 > c.x &&
            player.y + 25 < c.y + c.h && player.y + player.h - 20 > c.y) {
            
            vidas--;
            invencivel = true;
            atualizarUI();

            if (vidas <= 0) {
                jogoAtivo = false;
                gameOverMsg.style.display = "block";
            } else {
                resetPos();
                // Dá 1 segundo de piscada/segurança para se mover
                setTimeout(() => { invencivel = false; }, 1000);
            }
        }
    });

    // Renderizar a Kuromi (efeito de piscar leve se estiver invencível)
    if (imagemCarregada) {
        if (!invencivel || Math.floor(Date.now() / 100) % 2 === 0) {
            ctx.drawImage(spriteKuromi, player.clipX, player.clipY, player.clipW, player.clipH, player.x, player.y, player.w, player.h);
        }
    } else {
        ctx.fillStyle = "#483D8B";
        ctx.fillRect(player.x, player.y, player.w, player.h);
    }

    // Condição de Vitória (Chegar na faixa superior)
    if (player.faixa === 0) {
        score++;
        player.ammo = Math.min(player.ammo + 2, 6); 
        atualizarUI();
        
        // Bloqueia colisões imediatamente na vitória para evitar duplo gatilho
        invencivel = true; 
        resetPos();

        winMsg.style.display = "block";
        setTimeout(() => {
            winMsg.style.display = "none";
            invencivel = false; // Libera movimentação segura de volta
        }, 1000);
    }

    requestAnimationFrame(loop);
}

function atualizarUI() {
    scoreElement.innerText = score;
    ammoElement.innerText = player.ammo;
    livesElement.innerText = "💖".repeat(Math.max(0, vidas)) || "💀";
}

function reiniciarJogo() {
    score = 0;
    vidas = 3;
    player.ammo = 3;
    projeteis = [];
    invencivel = false;
    jogoAtivo = true;
    
    gameOverMsg.style.display = "none";
    winMsg.style.display = "none";
    
    inicializar();
    loop();
}

window.addEventListener("keydown", (e) => {
    if (!jogoAtivo) return;
    
    if (e.key === "ArrowUp" && player.faixa > 0) player.faixa--;
    if (e.key === "ArrowDown" && player.faixa < totalFaixas - 1) player.faixa++;
    if (e.key === "ArrowLeft" && player.x > 0) player.x -= 35;
    if (e.key === "ArrowRight" && player.x < canvas.width - player.w) player.x += 35;
    
    if (e.key === " " || e.code === "Space") {
        e.preventDefault(); // Impede a página de descer usando a barra de espaço
        if (player.ammo > 0) {
            player.ammo--;
            atualizarUI();
            projeteis.push({ x: player.x + player.w/2 - 4, y: player.y, w: 8, h: 15 });
        }
    }
    player.y = (player.faixa * alturaFaixa) + (alturaFaixa - player.h);
});

window.addEventListener("resize", inicializar);

// Inicializa tudo limpo
inicializar();
loop();